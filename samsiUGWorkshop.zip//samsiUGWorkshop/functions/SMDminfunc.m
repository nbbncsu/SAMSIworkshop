function ssq = SMDminfunc(q,data,t,m,y0)
k=q(1);
c=q(2);

[~,y] = ode45(@(t,y) SMDsystem(t,y,m,k,c),t,y0);

ssq= sum((data-y(:,1)).^2);
end