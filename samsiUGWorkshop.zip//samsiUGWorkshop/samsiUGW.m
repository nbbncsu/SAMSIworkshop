%Code for SAMSI UG Workshop

%% Vectors 

x=1:10 %row vector of integers 

x(3) %3rd enrty in x

y=1:2:10 %row vector of integers from 1 to 9 counting by 2

%%
z=linspace(0,10,101)'; %column vector of 101 evenly spaces points from 0 to 10
z(3:15)

length(y)

%% Matrices

A=[1,2,3;,4,5,6;7,8,9] %creating matrix

A(1,2)

A(3,:)

2*A
%%

B = eye(3,2) % creates an matrix with ones of main diagonal of size 3-by-2

[m,n]=size(B) %return the size of the matrix

%%
C=A*B

C.*B

C+B

%% Matrix Functions
A = magic(3) % help magic

inv(A)%must be square

pinv(C)%moore-penrose inverse

det(A)%must be square

cond(A) %condition number

clear z
clear all

%% Cell Array

C = cell(2, 3);   % create 2x3 empty cell array 
M = magic(2);
a = 1:3; b = [4;5;6]; s = 'This is a string.';
C{1,1} = M; C{1,2} = a; C{2,1} = b; C{2,2} = s; C{1,3} = {1};

C
C{1,1}
C{:,2}


%% Grouping Array
name(1).last = 'Smith';   name(2).last  = 'Hess';
name(1).first = 'Mary';   name(2).first = 'Robert';
name(1).sex = 'female';   name(2).sex = 'male';
name(1).age = 45;         name(2).age = 50;
name(2) 

%save('nameData','name')

%% Loading Files
clear all
%loading data from a file
%load a mat file
addpath('data')
load('nameData.mat')

name(2)

%creating a txt file
% x = 100*randn(10,1)';
% fileID = fopen('nums1.txt','w');
% fprintf(fileID,'%4.4f\n',x);
% fclose(fileID);

%clear all
%loading a txt file
fileID = fopen('nums1.txt','r');
x = fscanf(fileID,'%f');
fclose(fileID);

x

%loading data from csv rile
gameData=csvread('gameData.csv',1,1);

gameData

%% Solving linear systems
A = [ 3 2 -1; -1 3 2; 1 -1 -1]
b = [ 10; 5; -1]
x = inv(A)*b
 
 %or
 
x = A\b

%% Eigenvectors and Value
A = [2 1 3;-2 0 -2;5 5 2];
X = A'*A
[Q,D] = eig(X)
%%
Q*D*inv(Q)
Q'
inv(Q)

%% Cholesky Decomp
R=chol(X)
R'*R

%% Singular Value Decomp
[W,S,V]=svd(A,'econ');
W*S*V'
S.^2

%clear all
%% Sampling out of a uniform distibution
y=-100 + (100- (-100))*rand(10,1) %[-100,100]

%% Sampling out of a normal distribution
mu = [0 5];
sigma = [1 0.75; 0.75 1.5];
R = chol(sigma);
z = repmat(mu,10,1) + randn(10,2)*R

clear all
%% Plotting

t = (0:1/100:1);
y = cos(2*pi*t);
y2 = sin(2*pi*t)+0.05*randn(1,length(t));

figure(1)
plot(t,y,'b',t,sin(2*pi*t),'r--',t,y2,'*k','LineWidth',3)
set(gca,'Fontsize',20)
xlabel('time [sec]')
ylabel('y(t)')
xlim([0,1])
ylim([-1.25,1.25])
box on
grid on
legend('cos(t)','sin(t)','sin(t)+noise')


%% DE Solver
clear all
%Generating data
% m(x'')+c(x')+kx=0, x(0)=3m, x'(0)=0
% x= cos(sqrt(k/m)t)

t=0:0.01:1; %s
m=2; %kg
k= 700; %kg/s^2
c=8; %kg/s

dy = @(t,y) [0,1;-k/m,-c/m]*y;

[~,y] = ode45(dy,t,[3;0]);
data = y(:,1)+[0;0.1*randn(length(t)-1,1)];

figure(2)
plot(t,y(:,1),t,data,'*k','LineWidth',3)
set(gca,'Fontsize',20)
xlabel('time [sec]')
ylabel('displacement [m]')
xlim([0,t(end)])
box on
grid on
legend('y(t)','data')

%% Optimization
addpath('functions')
y0=[3;0];
q0=[0;0];
qstar = fminsearch(@(q) SMDminfunc(q,data,t,m,y0),q0)

[~,ystar] = ode45(@(t,y) SMDsystem(t,y,m,qstar(1),qstar(2)),t,y0);

hold on
plot(t,ystar(:,1),'--','LineWidth',3)
legend('y(t)','data','y^*(t)')

%% Functions

% function ssq = SMDminfunc(q,data,t,m,y0)
% k=q(1);
% c=q(2);
% 
% [~,y] = ode45(@(t,y) SMDsystem(t,y,m,k,c),t,y0);
% 
% ssq= sum((data-y(:,1)).^2);
% end
% 
% function dy = SMDsystem(t,y,m,k,c)
% 
% dy = [0,1;-k/m,-c/m]*y;
% 
% end

