%Convergence test for mcpi
clear all

for i = 1:7
   piApprox(i)=mcpi(10^(1+i));
end

error=(abs(piApprox-pi)); % Errors

errorRatio= error(2:7)./(error(1:6)); %error Ratios (e_K+1)/(e_k)
