function dy = SMDsystem(t,y,m,k,c)

dy = [0,1;-k/m,-c/m]*y;

end