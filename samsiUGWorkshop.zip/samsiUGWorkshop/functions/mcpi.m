function [ piapprox ] = mcpi( n )

%UNTITLED Summary of this function goes here

%   Detailed explanation goes here

   clc;
   %randomly sampling points
x=rand(n,1);

y=rand(n,1);

%circle has center at (0.5,0.5)
% repositioning to (0,0)
x1=x-0.5;

y1=y-0.5; 

%finding radius of each set of points
r2=x1.^2+y1.^2;

m=0;   %Number of points inside circle

for i=1:n % testing point is in the circle
    if r2(i)<=0.25
        m=m+1;
    end   
end

piapprox = m/(0.25*n);
% error = 100*(abs(piapprox-pi)/pi)

end